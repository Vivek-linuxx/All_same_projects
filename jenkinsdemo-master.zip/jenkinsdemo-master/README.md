# jenkins-course
* This is the course material for the Jenkins Course on Udemy. See https://www.udemy.com/learn-devops-ci-cd-with-jenkins-using-pipelines-and-docker/?couponCode=JENKINS_GIT
